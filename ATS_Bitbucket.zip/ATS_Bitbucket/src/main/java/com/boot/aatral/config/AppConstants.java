package com.boot.aatral.config;

public class AppConstants {
	public static final String PAGE_NUMBER = "0";
	public static final String PAGE_SIZE = "10";
	public static final String SORT_BY = "postId";
	public static final String SORT_DIR = "asc";
	
	
	public static final Long ADMIN = 100l;

	public static final Long BU_MANAGER = 101l;

	public static final Long TA_MANAGER = 102l;

	public static final Long RR_MANAGER = 103l;
}