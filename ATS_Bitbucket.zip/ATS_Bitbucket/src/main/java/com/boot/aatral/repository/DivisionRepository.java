package com.boot.aatral.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.boot.aatral.entity.Division;

public interface DivisionRepository extends JpaRepository<Division, Long>{

}
