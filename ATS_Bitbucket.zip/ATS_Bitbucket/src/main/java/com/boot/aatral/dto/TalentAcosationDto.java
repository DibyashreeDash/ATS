package com.boot.aatral.dto;

import com.boot.aatral.entity.User;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class TalentAcosationDto {
	
	private int taId;
	private String client;
	private int numberOfPositions;
	private String projectName;
	private String assignToRecruiter;
	private String resourceStartDate;
	private String targetedDate;
	private String requestResourceId;
   //  private User userId; 

	


}
