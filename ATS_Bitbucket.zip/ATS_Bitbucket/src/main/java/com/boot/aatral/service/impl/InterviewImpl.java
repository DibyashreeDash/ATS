package com.boot.aatral.service.impl;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boot.aatral.dto.InterviewDto;
import com.boot.aatral.entity.Interview;
import com.boot.aatral.service.InterviewRepositery;
import com.boot.aatral.service.InterviewService;

@Service
public class InterviewImpl implements InterviewService {

	@Autowired
	private InterviewRepositery interviewRepositery;
	@Override
	public InterviewDto saveInterview(InterviewDto interviewDto) {
		
		Interview interview=new Interview();
		BeanUtils.copyProperties(interviewDto, interview);
		interviewRepositery.save(interview);
		return interviewDto;
	}
	
	

}
