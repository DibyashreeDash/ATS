package com.boot.aatral.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.boot.aatral.config.AppConstants;
import com.boot.aatral.dto.LoginForm;
import com.boot.aatral.dto.UserDto;
import com.boot.aatral.entity.Role;
import com.boot.aatral.entity.User;
import com.boot.aatral.exception.ResourceNotFoundException;
import com.boot.aatral.repository.RoleRepository;
import com.boot.aatral.repository.UserRepository;
import com.boot.aatral.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private RoleRepository roleRepo;

	@Override

	public UserDto createUser(UserDto userDto) {

		User user = this.modelMapper.map(userDto, User.class);

		user.setIsActive(true);

		Role role = null;

		switch (userDto.getRole().getRoleName()) {

		case "ADMIN":

			role = this.roleRepo.findById(AppConstants.ADMIN).orElse(null);

			break;

		case "BU_MANAGER":

			role = this.roleRepo.findById(AppConstants.BU_MANAGER).orElse(null);

			break;

		case "TA_MANAGER":

			role = this.roleRepo.findById(AppConstants.TA_MANAGER).orElse(null);

			break;

		case "RR_MANAGER":

			role = this.roleRepo.findById(AppConstants.RR_MANAGER).orElse(null);

			break;

		default:

			System.out.println("--------------NOT FOUND -----------------");

			break;

		}

		if (role != null) {

			user.setRole(role);

		}

		User newUser = this.userRepository.save(user);

		return this.modelMapper.map(newUser, UserDto.class);

	}

	@Override
	public UserDto getUser(String id) {
		User user = this.userRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("User", "id", id));
		return this.modelMapper.map(user, UserDto.class);
	}

	@Override
	public UserDto updateUser(UserDto userDto, String id) {
		User user = this.userRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("User", "id", id));
		user.setAddress(userDto.getAddress());
		user.setContactno(userDto.getContactno());
		user.setEmail(userDto.getEmail());
		user.setId(userDto.getId());
		user.setIsActive(userDto.getIsactive());
		user.setName(userDto.getName());
		user.setPassword(userDto.getPassword());
		User updateUser = this.userRepository.save(user);
		return this.modelMapper.map(updateUser, UserDto.class);
	}

	@Override
	public void deleteUser(String id) {
		User user = this.userRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("User", "id", id));
		user.setIsActive(false);
		this.userRepository.save(user);
	}

	@Override
	public List<UserDto> getAllUsers() {
		List<User> user = this.userRepository.findAll();
		List<UserDto> userDtos = user.stream().map((item) -> this.modelMapper.map(item, UserDto.class))
				.collect(Collectors.toList());
		return userDtos;
	}

	// Login api
	@Override
	public String Login(LoginForm form) {
		User data = this.userRepository.findByEmail(form.getEmail());

		if (data == null) {
			throw new ResourceNotFoundException("Data Not found", form.getEmail(), form.getRole());
		}

		if (data.getRole().equals(form.getRole()) && data.getPassword().equals(form.getPassword())) {

			return "LoginSuccessFul " + HttpStatus.ACCEPTED;
		}
		return "Invalid Credentials " + HttpStatus.BAD_REQUEST;
	}

	@Override
	public List<UserDto> findByName(String name) {
		List<User> byName = userRepository.findByName(name);
		List<UserDto> users = byName.stream().map((item) -> modelMapper.map(item, UserDto.class))
				.collect(Collectors.toList());
		return users;
	}

	@Override
	public List<UserDto> findRecruiter() {
		// TODO Auto-generated method stub
		List<User> list = userRepository.findAll();
		List<User> filterUser = list.stream()
				.filter(user -> user.getRole() != null && user.getRole().getRoleName().equalsIgnoreCase("recruiter"))
				.collect(Collectors.toList());
		List<UserDto> userDtos = filterUser.stream().map((item) -> modelMapper.map(item, UserDto.class))
				.collect(Collectors.toList());
		return userDtos;
	}

	@Override

	public List<UserDto> findRecruiters() {

		// TODO Auto-generated method stub

		List<User> list = userRepository.findAll();

		List<User> filterUser = list.stream()

				.filter(user -> user.getRole() != null && user.getRole().getRoleName().equalsIgnoreCase("RR_MANAGER"))

				.collect(Collectors.toList());

		List<UserDto> userDtos = filterUser.stream().map((item) -> modelMapper.map(item, UserDto.class))

				.collect(Collectors.toList());

		return userDtos;

	}
}
