package com.boot.aatral.entity;

import java.util.List;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
//Bu Related Activities
@Entity
public class BuManager {
//added comments
	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String requestResourceId;
	@CreationTimestamp
	private String requestRaisedDate;
	private String projectName;
	private String resourceStartDate;
	private String resourceEndDate;
	private String requestorName;
	private String designation;
	private String contactNumber;
	//private String email;
	private Integer numberOfPositions;
	// JOIN WITH USERS
	//private int empid;
	private String experienceLevel;
	private String modeOfWork;
	private String jobDescription;
	private String ctcOfferDetails;
	private String workLocation;
	private String client;

	//private Long divisionId;
	//private Long skillId;

	private String division;
	private List<String> skill;
	private Boolean isActive;
	private String buStatus;
	
		
	
	
	
}
