
/*
 * package com.boot.aatral.config;
 * 
 * import org.springframework.beans.factory.annotation.Value; import
 * org.springframework.context.annotation.Bean; import
 * org.springframework.context.annotation.Configuration;
 * 
 * import com.amazonaws.auth.AWSCredentials; import
 * com.amazonaws.auth.AWSStaticCredentialsProvider; import
 * com.amazonaws.auth.BasicAWSCredentials; import com.amazonaws.regions.Regions;
 * import com.amazonaws.services.s3.AmazonS3; import
 * com.amazonaws.services.s3.AmazonS3ClientBuilder;
 * 
 * @Configuration public class AwsS3Config {
 * 
 * @Value("${amazon.aws.access-key}") private String accessKeyId;
 * 
 * @Value("${amazon.aws.secret-key}") private String accessKeySecret;
 * 
 * @Value("${amazon.aws.region}") private String s3RegionName;
 * 
 * @Bean AmazonS3 getAmazonS3Client() { AWSCredentials credentials = new
 * BasicAWSCredentials(this.accessKeyId, this.accessKeySecret); return
 * AmazonS3ClientBuilder.standard().withRegion(Regions.AP_SOUTH_1)
 * .withCredentials(new AWSStaticCredentialsProvider(credentials)).build(); } }
 */

package com.boot.aatral.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class AwsS3Config {
	/*
	 * @Value("${amazon.aws.access-key}") private String accessKeyId;
	 * 
	 * @Value("${amazon.aws.secret-key}") private String accessKeySecret;
	 * 
	 * @Value("${amazon.aws.region}") private String s3RegionName;
	 * 
	 * @Bean AmazonS3 getAmazonS3Client() { AWSCredentials credentials = new
	 * BasicAWSCredentials(this.accessKeyId, this.accessKeySecret); return
	 * AmazonS3ClientBuilder.standard().withRegion(Regions.AP_SOUTH_1)
	 * .withCredentials(new AWSStaticCredentialsProvider(credentials)).build(); }
	 */
}

