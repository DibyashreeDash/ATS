package com.boot.aatral.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@Entity
@Table(name = "Talent_Acquisation")
public class TalentAcosation {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int taId;
	private String client;
	private int numberOfPositions;
	private String projectName;
	private String assignToRecruiter;
	private String resourceStartDate;
	private String targetedDate;
	private String email;

	private String taStatus;

	@OneToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "user_id")
	private User user;
	/*
	 * @JsonBackReference
	 * 
	 * @OneToMany(mappedBy = "talentAcosation", cascade = CascadeType.ALL, fetch =
	 * FetchType.EAGER) private List<Recruiter> recruiter = new ArrayList<>();
	 */

}
