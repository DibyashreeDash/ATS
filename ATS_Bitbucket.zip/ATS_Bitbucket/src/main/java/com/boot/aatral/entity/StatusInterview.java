package com.boot.aatral.entity;

public enum StatusInterview {
InProgress,
ShortListed
}
