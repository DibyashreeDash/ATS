package com.boot.aatral.dto;

import lombok.Data;

@Data
public class ClientDto {

	private String clientId;
	private String clientName;
	private String clientLocation;
	private Boolean status;
}
