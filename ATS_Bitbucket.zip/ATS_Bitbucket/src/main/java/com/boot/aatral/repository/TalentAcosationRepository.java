package com.boot.aatral.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.boot.aatral.entity.TalentAcosation;

@Repository
public interface TalentAcosationRepository extends JpaRepository<TalentAcosation, Integer>{

}
