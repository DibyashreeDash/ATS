package com.boot.aatral.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.boot.aatral.dto.RecruiterDto;
import com.boot.aatral.entity.Recruiter;
import com.boot.aatral.entity.Status;
import com.boot.aatral.repository.RecruiterRepository;
import com.boot.aatral.service.RecruiterService;

@RestController
@CrossOrigin("http://localhost:3000")
@RequestMapping("/api/recruiter")
public class RecruiterController {

	@Autowired
	private RecruiterService recruiterService;
	
	@Autowired
	private RecruiterRepository recruiterRepository;

	@PostMapping("/save")
	public ResponseEntity<RecruiterDto> createRecruiter(@RequestBody RecruiterDto recruiterDto) {
		RecruiterDto createdRecruiterDto = this.recruiterService.createRecruiter(recruiterDto);
		return new ResponseEntity<RecruiterDto>(createdRecruiterDto, HttpStatus.OK);
	}
	@GetMapping("/getAll")
	public ResponseEntity<List<RecruiterDto>> getRecruiters() {
		return ResponseEntity.ok(recruiterService.getRecruiters());
	}

    @GetMapping("/findByStatus/{status}")
    public List<Recruiter> findByStatus(@PathVariable Status status) {
        return recruiterRepository.findByStatus(status);
    }

}
