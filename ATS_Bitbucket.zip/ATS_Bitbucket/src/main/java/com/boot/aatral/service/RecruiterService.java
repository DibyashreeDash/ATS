package com.boot.aatral.service;

import java.util.List;

import com.boot.aatral.dto.RecruiterDto;



public interface RecruiterService 
{
   RecruiterDto createRecruiter(RecruiterDto recruiterDto);
	  
	  
   RecruiterDto updateRecruiter(RecruiterDto recruiterDto,Integer   recruiterId);
	    
	  
	  List<RecruiterDto> getRecruiters();
	  
	  RecruiterDto  getRecruiterById(Integer  recruiterId );
	  
	  void deleteRecruiter(Integer  recruiterId);
	

  
}
