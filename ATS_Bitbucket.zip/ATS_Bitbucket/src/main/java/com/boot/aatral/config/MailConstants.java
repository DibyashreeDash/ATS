package com.boot.aatral.config;

public class MailConstants {

	public static String mailL1 = "congratulation you are selected for L1";
	public static String mailL2 = "congratulation you are selected for L2";
	public static String mailL3 = "congratulation you are selected for L3";
	public static String mailL4 = "congratulation you are selected for L4";

}
