package com.boot.aatral.dto;

import com.boot.aatral.entity.Candidate;
import com.boot.aatral.entity.LevelOfInterview;
import com.boot.aatral.entity.Mode;
import com.boot.aatral.entity.Platform;
import com.boot.aatral.entity.StatusInterview;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import lombok.Data;

@Data

public class InterviewDto {

	private String panelPerson;
	
	private String email;

	private LevelOfInterview levelOfInterview;

	private Mode mode;

	private Platform platform;

	@Enumerated(EnumType.STRING)
	private StatusInterview statusInterview;

	@OneToOne
	@JoinColumn(name = "candidate_id")
	private Candidate candidate;
}
