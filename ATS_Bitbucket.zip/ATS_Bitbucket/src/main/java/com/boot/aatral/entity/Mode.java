package com.boot.aatral.entity;

public enum Mode {
F2F,
VIRTUAL
}
