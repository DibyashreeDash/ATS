package com.boot.aatral.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data
public class Role {
    @Id
    @Column(name = "role_id")
    @GeneratedValue
    private Long id;
    private String roleName;

	
//	@JsonManagedReference
//    @OneToMany(mappedBy = "role", fetch = FetchType.EAGER)
//    private List<User> users= new ArrayList<>();
}