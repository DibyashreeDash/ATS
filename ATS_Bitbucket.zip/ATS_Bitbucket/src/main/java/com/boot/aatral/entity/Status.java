package com.boot.aatral.entity;

public enum Status {

	DONE, PROGRESS
}
