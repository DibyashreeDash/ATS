package com.boot.aatral.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boot.aatral.dto.BuDashBoard;
import com.boot.aatral.service.IBuDashboard;

@RestController
@RequestMapping("/api/budashboard")
public class BuDashboardController {
	
	@Autowired
	private IBuDashboard buDashboard;
	
	@GetMapping("/dashboard")
	public ResponseEntity<BuDashBoard> dashBoard()
	{
	   
		BuDashBoard dashBoard1 = buDashboard.dashBoard1();
		return new ResponseEntity<BuDashBoard>(dashBoard1,HttpStatus.OK);
		
	}

}
