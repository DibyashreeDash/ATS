package com.boot.aatral.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boot.aatral.dto.BuDashBoard;
import com.boot.aatral.repository.BuManagerRepository;
import com.boot.aatral.repository.TalentAcosationRepository;
import com.boot.aatral.service.IBuDashboard;

@Service
public class BuDashBoardImpl implements IBuDashboard {
	
	@Autowired
	private BuManagerRepository buManagerRepository;
 
	@Autowired
	private TalentAcosationRepository  acosationRepository;

	@Override
	public BuDashBoard dashBoard1() {

		BuDashBoard dashBoard=new BuDashBoard();
		long count = buManagerRepository.count();
		long count2 = acosationRepository.count();
		dashBoard.setBuRaisedRequests(count);
		dashBoard.setTaClosedRequests(count2);
		return dashBoard;
	}
	
	
}
