package com.boot.aatral.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boot.aatral.dto.RecruiterDto;
import com.boot.aatral.dto.TalentAcosationDto;
import com.boot.aatral.entity.BuManager;
import com.boot.aatral.entity.Recruiter;
import com.boot.aatral.entity.TalentAcosation;
import com.boot.aatral.entity.User;
import com.boot.aatral.repository.BuManagerRepository;
import com.boot.aatral.repository.TalentAcosationRepository;
import com.boot.aatral.repository.UserRepository;
import com.boot.aatral.service.TalentAcosationService;

@Service
public class TalentAcosationServiceImpl implements TalentAcosationService{
	
	
	@Autowired
	private ModelMapper modelMapper;
	

	@Autowired
	private TalentAcosationRepository talentAcosationRepository;
	
	@Autowired
	private BuManagerRepository buManagerRepository;
	
	@Autowired
	private UserRepository userRepositery;
	
	@Override
	public TalentAcosationDto createTalentAcosation(TalentAcosationDto talentAcosationDto,String email) {
		
		User useremail = userRepositery.findByEmail(email);
		String email2 = useremail.getEmail();
		TalentAcosation talentAcosation=new TalentAcosation();
		talentAcosation.setEmail(useremail.getEmail());
		BeanUtils.copyProperties(talentAcosationDto, talentAcosation);
		talentAcosationRepository.save(talentAcosation);
		return talentAcosationDto;
		
		
		/*
		 * System.out.println(talentAcosationDto.getProjectName());
		 * 
		 * 
		 * 
		 * System.out.println("talentAcosationDto------------------------->"+
		 * talentAcosationDto.getTargetedDate());
		 * 
		 * TalentAcosation talentAcosation =
		 * this.dtoToTalentAcosation(talentAcosationDto); TalentAcosation
		 * savedTalentAcosation = this.talentAcosationRepository.save(talentAcosation);
		 * talentAcosation.setTaStatus("closed"); return
		 * this.TalentAcosationToDto(savedTalentAcosation);
		 */
	}

	@Override
	public TalentAcosationDto updateTalentAcosation(TalentAcosationDto talentAcosationDto, Integer taId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<TalentAcosationDto> getTalentAcosationDtos() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TalentAcosationDto getTalentAcosationDtoById(Integer taId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteTalentAcosation(Integer taId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<TalentAcosationDto> getAll() {
		List<TalentAcosationDto> list1=new ArrayList<TalentAcosationDto>();
		List<TalentAcosation> list = talentAcosationRepository.findAll();
		for(TalentAcosation o:list) {
			System.out.println(o.getTargetedDate());
			TalentAcosationDto dto = this.modelMapper.map(o, TalentAcosationDto.class);
			list1.add(dto);
		}
		TalentAcosationDto dto = this.modelMapper.map(list, TalentAcosationDto.class);
		return list1;
	}

//	@Override
//	public List<TalentAcosationDto> getAll() {
//	    List<TalentAcosationDto> list1 = new ArrayList<>();
//	    List<TalentAcosation> list = talentAcosationRepository.findAll();
//	    for (TalentAcosation talentAcosation : list) {
//	        TalentAcosationDto dto = this.modelMapper.map(talentAcosation, TalentAcosationDto.class);
//	        list1.add(dto);
//	    }
//	    return list1;
//	}

	/*
	 * @Override public List<TalentAcosationDto> getAll() { List<TalentAcosationDto>
	 * dtos = new ArrayList<>(); List<TalentAcosation> talentAcosations =
	 * talentAcosationRepository.findAll(); for (TalentAcosation talentAcosation :
	 * talentAcosations) { TalentAcosationDto dto = new TalentAcosationDto(); // Map
	 * properties manually or use your modelMapper if configured properly
	 * dto.setTaId(talentAcosation.getTaId());
	 * dto.setClient(talentAcosation.getClient());
	 * dto.setNumberOfPositions(talentAcosation.getNumberOfPositions());
	 * dto.setProjectName(talentAcosation.getProjectName());
	 * dto.setAssignToRecruiter(talentAcosation.getAssignToRecruiter());
	 * dto.setResourceStartDate(talentAcosation.getResourceStartDate());
	 * dto.setTargetedDate(talentAcosation.getTargetedDate());
	 * dto.setUser(talentAcosation.getUser());
	 * 
	 * dtos.add(dto); }
	 * 
	 * return dtos; }
	 */

	
private TalentAcosation dtoToTalentAcosation(TalentAcosationDto talentAcosationDto) {
		
	TalentAcosation talentAcosation= this.modelMapper.map(talentAcosationDto, TalentAcosation.class);
		return talentAcosation;
	}
	
	private TalentAcosationDto TalentAcosationToDto(TalentAcosation talentAcosation) {
		TalentAcosationDto talentAcosationDto = this.modelMapper.map(talentAcosation, TalentAcosationDto.class);
		return talentAcosationDto;
	}
}
