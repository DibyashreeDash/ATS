package com.boot.aatral.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.boot.aatral.entity.BuManager;

public interface BuManagerRepository extends JpaRepository<BuManager, String> {

	//BuManager findByRequestResourceId(String requestResourceId);
	
}
