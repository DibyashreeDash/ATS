package com.boot.aatral.service;

import com.boot.aatral.dto.InterviewDto;
import com.boot.aatral.entity.Interview;

public interface InterviewService {
 
	InterviewDto saveInterview(InterviewDto interview );
	
}
