package com.boot.aatral.service.impl;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.boot.aatral.dto.CandidateDto;
import com.boot.aatral.entity.Candidate;
import com.boot.aatral.exception.ResourceNotFoundException;
import com.boot.aatral.repository.CandidateRepository;
import com.boot.aatral.service.CandidateService;

@Service
public class CandidateServiceImpl implements CandidateService {

	@Autowired
	private CandidateRepository candidateRepository;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private JavaMailSender javaMailSender;


	//@Value("${aws.s3.bucketName}")
	//private String bucketName;

	//@Autowired
	//private AmazonS3 amazonS3;

//	@Override
	//public CandidateDto createCandidate(CandidateDto candidateDto, MultipartFile file) throws IOException {
	//	Candidate candidate = modelMapper.map(candidateDto, Candidate.class);

		// Upload resume to S3
		//amazonS3.putObject(new PutObjectRequest(bucketName, file.getOriginalFilename(), file.getInputStream(), null));

		// Store file information in the database
	//	String resumeUrl = amazonS3.getUrl(bucketName, file.getOriginalFilename()).toString();

		//candidate.setStatus(true);
		//candidate.setResume(resumeUrl);

		//Candidate savedCandidate = this.candidateRepository.save(candidate);
		//return this.modelMapper.map(savedCandidate, CandidateDto.class);

	/*
	 * @Value("${aws.s3.bucketName}") private String bucketName;
	 * 
	 * @Autowired private AmazonS3 amazonS3;
	 */

	public CandidateDto createCandidate(CandidateDto candidateDto) {
		Candidate candidate = new Candidate();
		candidate.setStatus("In Progress");
		BeanUtils.copyProperties(candidateDto, candidate);
		candidateRepository.save(candidate);
		
		return candidateDto;


	}

	@Override
	public CandidateDto updateCandidate(CandidateDto candidateDto,  Integer id) {// , MultipartFile file, Integer id) throws
		Candidate candidate2 = candidateRepository.findById(id)
			.orElseThrow(() -> new ResourceNotFoundException("Candidate", "Candidate Id", id));
		//CandidateDto candidateDto=new CandidateDto();
		BeanUtils.copyProperties(candidateDto, candidate2);
		candidateRepository.save(candidate2);
		return candidateDto;
	}

		// Upload resume to S3
		//amazonS3.putObject(new PutObjectRequest(bucketName, file.getOriginalFilename(), file.getInputStream(), null));

		// Store file information in the database
	//	String resumeUrl = amazonS3.getUrl(bucketName, file.getOriginalFilename()).toString();

		//candidate.setStatus(true);
		//candidate.setResume(resumeUrl);

		//candidate.setInterviewLevel(candidateDto.getInterviewLevel());
		//Candidate updatedCandidate = this.candidateRepository.save(candidate);
		//return this.modelMapper.map(updatedCandidate, CandidateDto.class);

	//}
	/*
	 * Candidate candidate = this.candidateRepository.findById(id) .orElseThrow(()
	 * -> new ResourceNotFoundException("Candidate", "Candidate Id", id));
	 * candidate.setCandidateContactNumber(candidateDto.getCandidateContactNumber())
	 * ;
	 * candidate.setCandidateCurrentAddress(candidateDto.getCandidateCurrentAddress(
	 * )); candidate.setCandidateCurrentLocation(candidateDto.
	 * getCandidateCurrentLocation());
	 * candidate.setCandidateEmail(candidateDto.getCandidateEmail());
	 * candidate.setCandidateFirstName(candidateDto.getCandidateFirstName());
	 * candidate.setCandidateLastName(candidateDto.getCandidateLastName());
	 * candidate.setCandidateMiddleName(candidateDto.getCandidateMiddleName());
	 * candidate.setCandidatePanNumber(candidateDto.getCandidatePanNumber());
	 * candidate.setCandidatePermanentAddress(candidateDto.
	 * getCandidatePermanentAddress()); //candidate.setStatus(true);
	 * candidate.setClientLocation(candidateDto.getClientLocation());
	 * candidate.setCurrentDate(candidateDto.getCurrentDate());
	 * candidate.setDOB(candidateDto.getDOB());
	 * candidate.setGender(candidateDto.getGender());
	 * candidate.setRelevantExperience(candidateDto.getRelevantExperience());
	 * candidate.setTotalExperience(candidateDto.getRelevantExperience());
	 * 
	 * // Upload resume to S3 //amazonS3.putObject(new PutObjectRequest(bucketName,
	 * file.getOriginalFilename(), file.getInputStream(), null));
	 * 
	 * // Store file information in the database
	 * 
	 * String resumeUrl = amazonS3.getUrl(bucketName,
	 * file.getOriginalFilename()).toString();
	 * 
	 * candidate.setStatus(true); candidate.setResume(resumeUrl);
	 * 
	 * 
	 * Candidate updatedCandidate = this.candidateRepository.save(candidate); return
	 * this.modelMapper.map(updatedCandidate, CandidateDto.class);
	 */

	@Override
	public List<CandidateDto> getAllCandidate() {
		List<Candidate> candidates = this.candidateRepository.findAll();
		List<CandidateDto> candidatesDto = candidates.stream()
				.map((item) -> this.modelMapper.map(item, CandidateDto.class)).collect(Collectors.toList());
		return candidatesDto;
	}

	@Override
	public CandidateDto getCandidateById(Integer id) {
		Candidate candidate = this.candidateRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("CAndidate", "Candidate Id", id));
		return this.modelMapper.map(candidate, CandidateDto.class);
	}

	@Override
	public void deleteCandidate(Integer id) {
		Candidate candidate = this.candidateRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("CAndidate", "Candidate Id", id));
		// candidate.setStatus(false);
	}

	public void sendEmail(String userTo, String adminTo, String subject, String userText, String adminText) {
		SimpleMailMessage userMessage = new SimpleMailMessage();
		userMessage.setTo(userTo);
		userMessage.setSubject(subject);
		userMessage.setText(userText);

		SimpleMailMessage adminMessage = new SimpleMailMessage();
		adminMessage.setTo(adminTo);
		adminMessage.setSubject(subject);
		adminMessage.setText(adminText);

		javaMailSender.send(userMessage);
		javaMailSender.send(adminMessage);
	}


}
