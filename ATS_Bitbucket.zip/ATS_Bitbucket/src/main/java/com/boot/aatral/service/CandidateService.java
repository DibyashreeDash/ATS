package com.boot.aatral.service;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.boot.aatral.dto.CandidateDto;

public interface CandidateService {

	// create employee
	CandidateDto createCandidate(CandidateDto candidateDto);//, MultipartFile file) throws IOException;

	// update employee
	CandidateDto updateCandidate(CandidateDto candidateDto,  Integer id);//, MultipartFile file, Integer id) throws Exception;

	// get all employee
	List<CandidateDto> getAllCandidate();

	// get single employee
	CandidateDto getCandidateById(Integer id);

	// delete employee
	void deleteCandidate(Integer id);

	// mail to candidate
	void sendEmail(String userTo, String adminTo, String subject, String userText, String adminText);
}
