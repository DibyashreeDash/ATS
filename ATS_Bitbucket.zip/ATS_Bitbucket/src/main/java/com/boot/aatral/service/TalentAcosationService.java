package com.boot.aatral.service;

import java.util.List;

import com.boot.aatral.dto.TalentAcosationDto;
import com.boot.aatral.entity.BuManager;

public interface TalentAcosationService {

	TalentAcosationDto createTalentAcosation(TalentAcosationDto talentAcosationDto ,String email);

	TalentAcosationDto updateTalentAcosation(TalentAcosationDto talentAcosationDto, Integer taId);

	List<TalentAcosationDto> getTalentAcosationDtos();

	TalentAcosationDto getTalentAcosationDtoById(Integer taId);

	void deleteTalentAcosation(Integer taId);

	List<TalentAcosationDto> getAll();

}
