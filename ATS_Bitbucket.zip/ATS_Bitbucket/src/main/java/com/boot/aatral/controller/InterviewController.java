package com.boot.aatral.controller;

public class InterviewController {

}
