package com.boot.aatral.service;

import org.springframework.data.jpa.repository.JpaRepository;

import com.boot.aatral.entity.Interview;

public interface InterviewRepositery extends JpaRepository<Interview, Integer> {

}
