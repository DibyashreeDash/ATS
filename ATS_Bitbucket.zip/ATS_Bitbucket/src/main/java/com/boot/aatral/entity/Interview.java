package com.boot.aatral.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@Entity
public class Interview {
 @Id
 @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int interviewId;
	private String panelPerson;
	private String resume;
	private String email;
	
	
	@Enumerated(EnumType.STRING)
	private LevelOfInterview levelOfInterview;
	
	@Enumerated(EnumType.STRING)
	private Mode mode;
	
	@Enumerated(EnumType.STRING)
	private Platform platform;
	
	@Enumerated(EnumType.STRING)
	private StatusInterview statusInterview;
	
	@OneToOne
	 @JoinColumn(name = "candidate_id")
	private Candidate candidate;
	
}
