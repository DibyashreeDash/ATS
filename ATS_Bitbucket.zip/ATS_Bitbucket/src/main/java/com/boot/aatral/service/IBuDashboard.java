package com.boot.aatral.service;

import com.boot.aatral.dto.BuDashBoard;

public interface IBuDashboard {

	public BuDashBoard dashBoard1();
	
	
}
