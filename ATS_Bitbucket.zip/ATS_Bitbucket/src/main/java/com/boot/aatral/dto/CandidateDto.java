package com.boot.aatral.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CandidateDto {
	private Integer candidateId;
	@NotEmpty
	@Size(min = 3, message = "candidate First Name must be minimum of 3 characters")
	private String candidateFirstName;
	@NotEmpty
	@Size(min = 3, message = "candidate Middle Name must be minimum of 3 characters")
	private String candidateMiddleName;
	@NotEmpty
	@Size(min = 1, message = "candidate Last Name must be minimum of 1 characters")
	private String candidateLastName;
	@Email(message = "Email address is not valid !!")
	@NotEmpty(message = "Email is required !!")
	private String candidateEmail;
	@NotEmpty
	@Size(min = 1, message = "candidate total experience must be minimum of 1 characters")
	private String totalExperience;
	@NotEmpty
	@Size(min = 1, message = "candidate relevant experience must be minimum of 1 characters")
	private String relevantExperience;
	
	private String candidateContactNumber;
	private String DOB;
	private String Gender;
	private String candidatePanNumber;
	private String candidateCurrentLocation;
	private String clientLocation;
	private String candidateCurrentAddress;
	private String candidatePermanentAddress;
	private String currentDate;
	//private String resume;
	private String status;
	
	
}
