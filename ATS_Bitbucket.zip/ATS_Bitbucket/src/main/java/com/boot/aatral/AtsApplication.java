package com.boot.aatral;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import com.boot.aatral.config.AppConstants;
import com.boot.aatral.entity.Role;
import com.boot.aatral.repository.RoleRepository;

@SpringBootApplication
public class AtsApplication implements CommandLineRunner{
	@Autowired
	private RoleRepository roleRepo;	
	
	public static void main(String[] args) {
		SpringApplication.run(AtsApplication.class, args);
		
	}

	@Bean
	ModelMapper modelMapper() {
		return new ModelMapper();
	}
	@Bean
	JavaMailSenderImpl mailSender() {
		JavaMailSenderImpl javaMailSender = new JavaMailSenderImpl();
		javaMailSender.setProtocol("SMTP");
		javaMailSender.setHost("127.0.0.1");
		javaMailSender.setPort(587);
		return javaMailSender;
	}

	@Override

	public void run(String... args) throws Exception {

		try {

			Role role1 = new Role();

			role1.setId(AppConstants.BU_MANAGER);

			role1.setRoleName("BU_MANAGER");

 

			Role role2 = new Role();

			role2.setId(AppConstants.TA_MANAGER);

			role2.setRoleName("TA_MANAGER");

 

			Role role3 = new Role();

			role3.setId(AppConstants.RR_MANAGER);

			role3.setRoleName("RR_MANAGER");

 

			List<Role> roles = List.of(role1, role2, role3);

			List<Role> result = roleRepo.saveAll(roles);

 

			result.forEach((item) -> System.out.println(item.getRoleName() + " -> " + item.getId()));

		} catch (Exception e) {

			e.printStackTrace();

		}

 
	}}
