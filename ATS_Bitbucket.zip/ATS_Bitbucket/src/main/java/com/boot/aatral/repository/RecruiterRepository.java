package com.boot.aatral.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.boot.aatral.entity.Recruiter;
import com.boot.aatral.entity.Status;


public interface RecruiterRepository extends JpaRepository<Recruiter,Integer> 
{
	List<Recruiter> findByStatus(Status status);
}
