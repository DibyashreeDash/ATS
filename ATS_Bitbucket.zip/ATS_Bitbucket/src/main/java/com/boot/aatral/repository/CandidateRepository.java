package com.boot.aatral.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.boot.aatral.entity.Candidate;

public interface CandidateRepository extends JpaRepository<Candidate, Integer> {

	@Query("select c.candidateEmail from Candidate c where c.candidateEmail= :candidateEmail")
	String existByEmail(@Param("candidateEmail") String candidateEmail);
}
