package com.boot.aatral.dto;

import com.boot.aatral.entity.Status;
import com.boot.aatral.entity.TalentAcosation;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class RecruiterDto {
	private int recruiterId;
	private Status status;

	private TalentAcosation talentAcosation;
}
