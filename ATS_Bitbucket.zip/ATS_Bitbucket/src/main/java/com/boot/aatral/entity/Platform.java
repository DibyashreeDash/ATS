package com.boot.aatral.entity;

public enum Platform {
 MSD,
 ZOOM,
 GOOFLEMEET
}
