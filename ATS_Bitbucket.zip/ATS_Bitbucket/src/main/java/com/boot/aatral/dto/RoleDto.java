package com.boot.aatral.dto;

import java.util.ArrayList;
import java.util.List;

import com.boot.aatral.entity.User;

import lombok.Data;

@Data
public class RoleDto {
    private Long id;
    private String roleName;
    
//    private List<User> users= new ArrayList<>();
}