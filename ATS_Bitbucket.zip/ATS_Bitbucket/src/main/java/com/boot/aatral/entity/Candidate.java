package com.boot.aatral.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "CANDIDATES")
public class Candidate {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer candidateId;

	private String candidateFirstName;
	private String candidateMiddleName;
	private String candidateLastName;
	private String candidateEmail;
	private String totalExperience;
	private String relevantExperience;
	private String candidateContactNumber;
	private String DOB;
	private String Gender;
	private String candidatePanNumber;
	private String candidateCurrentLocation;
	private String clientLocation;
	private String candidateCurrentAddress;
	private String candidatePermanentAddress;

	@Column(name = "todays_date")
	private String currentDate;

//	private String interviewLevel;
	private String status;
	//private String resume;
}
