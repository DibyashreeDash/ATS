package com.boot.aatral.service;

import java.util.List;

import com.boot.aatral.dto.LoginForm;
import com.boot.aatral.dto.UserDto;
import com.boot.aatral.entity.User;

public interface UserService {

	UserDto createUser(UserDto userDto);

	UserDto getUser(String id);

	UserDto updateUser(UserDto userDto, String id);
	
	void deleteUser(String id);
	
	List<UserDto> getAllUsers();
	
	//Login api
	public String Login(LoginForm form );
	
	
	public  List<UserDto> findByName(String name);
	
	
	public List<UserDto> findRecruiter();
	
	public List<UserDto> findRecruiters();
}
