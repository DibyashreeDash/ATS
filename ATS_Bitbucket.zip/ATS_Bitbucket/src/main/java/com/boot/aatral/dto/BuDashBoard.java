package com.boot.aatral.dto;

import lombok.Data;

@Data
public class BuDashBoard {

	long buRaisedRequests;
	long taClosedRequests;
	
	
	
	
}
