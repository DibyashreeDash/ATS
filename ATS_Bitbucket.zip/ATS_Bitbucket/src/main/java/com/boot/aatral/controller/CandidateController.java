package com.boot.aatral.controller;

import java.io.IOException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.beans.factory.annotation.Value;

import com.boot.aatral.config.MailConstants;
import com.boot.aatral.dto.CandidateDto;
import com.boot.aatral.repository.CandidateRepository;
import com.boot.aatral.service.CandidateService;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@CrossOrigin("http://localhost:3000")
@RequestMapping("/api/candidate")
public class CandidateController {

	@Autowired
	private CandidateService candidateService;

	@Autowired
	private CandidateRepository candidateRepository;

	@Autowired
	private ObjectMapper objectMapper;

	/*
	 * @Value("${spring.mail.username}") private String adminEmail;
	 */

	// create
	@PostMapping(value = "/createCandidate")//, consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CandidateDto> createCandidate(@RequestBody CandidateDto userData) throws IOException {
     CandidateDto createCandidate = candidateService.createCandidate(userData);
		return new ResponseEntity<CandidateDto>(createCandidate, HttpStatus.CREATED);
	}

	// update
	@PutMapping(value = "/updateCandidate/{id}")//, consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CandidateDto> updateCandidate(@RequestBody  CandidateDto candidateDto,  @PathVariable Integer id) throws Exception  {
		//CandidateDto candidateDto = objectMapper.readValue(userData, CandidateDto.class);
		CandidateDto updateCandidate = this.candidateService.updateCandidate( candidateDto ,id);
		return new ResponseEntity<CandidateDto>(updateCandidate, HttpStatus.OK);
	}

	// delete
	@DeleteMapping("deleteCandidate/{id}")
	public ResponseEntity<Object> deleteCandidate(@PathVariable Integer id) {
		this.candidateService.deleteCandidate(id);
		return new ResponseEntity<Object>("Candidate deleted", HttpStatus.OK);
	}

	// getSingle
	@GetMapping("/getCandidate/{id}")
	public ResponseEntity<CandidateDto> getSingleCandidate(@PathVariable Integer id) {
		CandidateDto candidate = this.candidateService.getCandidateById(id);
		return new ResponseEntity<CandidateDto>(candidate, HttpStatus.OK);
	}

	// get all
	@GetMapping("/getAllCandidates")
	public ResponseEntity<List<CandidateDto>> getAllCAndidates() {
		List<CandidateDto> allCandidate = this.candidateService.getAllCandidate();
		return new ResponseEntity<List<CandidateDto>>(allCandidate, HttpStatus.OK);
	}

	// send mail to user
	@PostMapping("/register")
	public ResponseEntity<String> registerUser(@RequestBody CandidateDto candidateDto) {
		if (candidateRepository.existByEmail(candidateDto.getCandidateEmail()) != null) {
			return new ResponseEntity<String>("Email is already taken", HttpStatus.BAD_REQUEST);
		}
//		this.candidateService.createCandidate(candidateDto);

		String userTo = candidateDto.getCandidateEmail();
	//	String adminTo = adminEmail;
		String subject = candidateDto.getCandidateFirstName() + " Your application update";
		String userText = null;
	

		//candidateService.sendEmail(userTo, adminTo, subject, userText, adminText);

		return new ResponseEntity<String>("User Registered successfully !", HttpStatus.CREATED);
	}

}
