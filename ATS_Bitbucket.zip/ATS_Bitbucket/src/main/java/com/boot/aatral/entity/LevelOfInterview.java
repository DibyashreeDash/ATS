package com.boot.aatral.entity;

public enum LevelOfInterview
{
 L1,
 L2,
 L3,
 L4
}
