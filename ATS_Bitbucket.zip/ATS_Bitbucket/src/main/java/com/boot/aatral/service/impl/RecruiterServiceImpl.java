package com.boot.aatral.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boot.aatral.dto.RecruiterDto;
import com.boot.aatral.entity.Recruiter;
import com.boot.aatral.entity.Status;
import com.boot.aatral.repository.RecruiterRepository;
import com.boot.aatral.service.RecruiterService;

@Service
public class RecruiterServiceImpl implements RecruiterService {

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private RecruiterRepository recruiterRepository;

	@Override
	public RecruiterDto createRecruiter(RecruiterDto recruiterDto) {
		Recruiter recruiter = this.dtoToRecruiter(recruiterDto);
		if (recruiterDto.getStatus().equals("PROGRESS")) {
			recruiter.setStatus(Status.PROGRESS);
		}
		Recruiter savedRecruiter = this.recruiterRepository.save(recruiter);
		return this.RecruiterToDto(savedRecruiter);
	}

	@Override
	public RecruiterDto updateRecruiter(RecruiterDto recruiterDto, Integer recruiterId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<RecruiterDto> getRecruiters() {
		List<Recruiter> recruiters = this.recruiterRepository.findAll();

		// RecruiterDto map = this.modelMapper.map(recruiters, RecruiterDto.class);
		/*
		 * List<RecruiterDto> recruiterDtos = recruiters.stream() .map(recruiter ->
		 * this.modelMapper.map(recruiter,
		 * RecruiterDto.class)).collect(Collectors.toList()); return recruiterDtos;
		 */
		List<RecruiterDto> list=new ArrayList<RecruiterDto>();
		
		for(Recruiter dto:recruiters) {
			RecruiterDto map = modelMapper.map(dto, RecruiterDto.class);
			list.add(map);
		}
		return list;

	}

	@Override
	public RecruiterDto getRecruiterById(Integer recruiterId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteRecruiter(Integer recruiterId) {
		// TODO Auto-generated method stub

	}

	private Recruiter dtoToRecruiter(RecruiterDto recruiterDto) {

		Recruiter recruiter = this.modelMapper.map(recruiterDto, Recruiter.class);
		return recruiter;
	}

	private RecruiterDto RecruiterToDto(Recruiter recruiter) {
		RecruiterDto recruiterDto = this.modelMapper.map(recruiter, RecruiterDto.class);
		return recruiterDto;
	}

}
