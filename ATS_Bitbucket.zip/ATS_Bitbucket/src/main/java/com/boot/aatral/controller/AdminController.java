package com.boot.aatral.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boot.aatral.dto.LoginForm;
import com.boot.aatral.dto.UserDto;
import com.boot.aatral.response.ApiResponse;
import com.boot.aatral.response.ResponseHandler;
import com.boot.aatral.service.UserService;

import jakarta.validation.Valid;

@RestController
@CrossOrigin("http://localhost:3000")
@RequestMapping("/user/api")
public class AdminController {

	@Autowired
	private UserService userService;

	@PostMapping("/createuser")
	public ResponseEntity<Object> createUser(@Valid @RequestBody UserDto userDto) {
		UserDto createUserDto = this.userService.createUser(userDto);
		return ResponseHandler.responseBuilder("New user details are given here", HttpStatus.OK, createUserDto);

	}

	@GetMapping("/getuser/{id}")
	public ResponseEntity<Object> getSingleUser(@PathVariable String id) {
		UserDto userDto = this.userService.getUser(id);
		return ResponseHandler.responseBuilder("User details are given here", HttpStatus.OK, userDto);

	}

	@PutMapping("/updateuser/{id}")
	public ResponseEntity<Object> updateUser(@RequestBody UserDto userDto, @PathVariable String id) {
		UserDto updateUser = this.userService.updateUser(userDto, id);
		return ResponseHandler.responseBuilder("Updated user details are given here", HttpStatus.OK, updateUser);
	}

	@DeleteMapping("/deleteuser/{id}")
	public ResponseEntity<ApiResponse> deleteById(@PathVariable String id) {
		this.userService.deleteUser(id);
		return new ResponseEntity<ApiResponse>(new ApiResponse("User deleted successfully", false), HttpStatus.OK);
	}

	@GetMapping("/getallusers")
	public ResponseEntity<Object> getAllUsers() {
		List<UserDto> allUsers = this.userService.getAllUsers();
		return ResponseHandler.responseBuilder("Requested user details are given here", HttpStatus.OK, allUsers);
	}

	@PostMapping("/login")
	public ResponseEntity<String> loginCheck(@RequestBody LoginForm form) {
		String login = userService.Login(form);

		return new ResponseEntity<String>(login, HttpStatus.OK);

	}

	@GetMapping("/getByName/{name}")
	public ResponseEntity<Object> getByName(@PathVariable("name") String name) {
		if (name == null || name.isEmpty()) {
			return ResponseEntity.badRequest().build();
		}
		List<UserDto> users = userService.findByName(name);
		if (users == null) {
			// Create an error response using the custom ResponseHandler
			ResponseHandler errorResponse = new ResponseHandler("RESOURCE_NOT_FOUND", HttpStatus.NOT_FOUND);
			return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
		}
		// Create a success response using the custom ResponseHandler
		ResponseHandler successResponse = new ResponseHandler("Resource found successfully", HttpStatus.OK, users);
		return successResponse.getResponse();
	}

	@GetMapping("/findByRoleName/{name}")
	public ResponseEntity<List<UserDto>> findRecruiter(@PathVariable String name) {
		List<UserDto> recruiter = userService.findRecruiter();
		return new ResponseEntity<List<UserDto>>(recruiter, HttpStatus.OK);

	}

}
