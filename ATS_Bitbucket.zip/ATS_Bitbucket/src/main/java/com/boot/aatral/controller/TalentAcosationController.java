package com.boot.aatral.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.service.annotation.GetExchange;

import com.boot.aatral.dto.CandidateDto;
import com.boot.aatral.dto.TalentAcosationDto;
import com.boot.aatral.entity.BuManager;
import com.boot.aatral.service.TalentAcosationService;

@RestController
@CrossOrigin("http://localhost:3000")
@RequestMapping("/api/ta")
public class TalentAcosationController {

	@Autowired
	private TalentAcosationService talentAcosationService;

	@GetMapping("/save/{email}")
	public ResponseEntity<TalentAcosationDto> createTalentAcosation(
			@RequestBody TalentAcosationDto talentAcosationDto,@PathVariable String email) {
		

System.out.println("talentAcosationDto--------------->"+talentAcosationDto.getTargetedDate());

		TalentAcosationDto createTalentAcosationDto = this.talentAcosationService
				.createTalentAcosation(talentAcosationDto,email);
		return new ResponseEntity<TalentAcosationDto>(createTalentAcosationDto, HttpStatus.CREATED);
	}
	@GetMapping("/getbyId/{taId}")
	public ResponseEntity<TalentAcosationDto> getsingletamanager(@PathVariable Integer taId) 
	{
		TalentAcosationDto tamanager = this.talentAcosationService.getTalentAcosationDtoById(taId);
		return new ResponseEntity<TalentAcosationDto>(tamanager, HttpStatus.OK);
	}
@GetMapping("/getAll")
	public ResponseEntity<List<TalentAcosationDto>> getAll() {
		List<TalentAcosationDto> all = talentAcosationService.getAll();
		return new ResponseEntity<List<TalentAcosationDto>>(all, HttpStatus.OK);
	}
}
