package com.boot.aatral.response;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResponseHandler {

	private String message;
	
	private HttpStatus httpStatus;
	
	private Object data;
	
	
public ResponseHandler(String message, HttpStatus httpStatus) {
		
		this.message = message;
		this.httpStatus = httpStatus;
		System.out.println("++++++++++++++++++++++++++++");
	}

	
	  public static ResponseEntity<Object> responseBuilder(String message,
	  HttpStatus httpStatus, Object responseObject) {
	  System.out.println("---------------------------------"); Map<String, Object>
	  response = new HashMap<>(); response.put("message", message);
	  response.put("httpStatus", httpStatus); response.put("data", responseObject);
	  
	  return new ResponseEntity<Object>(response, httpStatus); }
	 
	public  ResponseEntity<Object> getResponse() {
		System.out.println("---------------------------------");
		Map<String, Object> response = new HashMap<>();
		response.put("message",message);
		response.put("httpStatus", httpStatus);
		response.put("data", data);

		return new ResponseEntity<Object>(response, httpStatus);
	}


	
}
