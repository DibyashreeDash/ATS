package com.boot.aatral.dto;

import java.util.List;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class BuManagerDto {

	private String requestResourceId;
	@NotEmpty
	@Size(min = 4, message = "Project Name must be minimum of 4 characters")
	private String projectName;
	@NotEmpty
	private String requestRaisedDate;
	@NotEmpty
	private String resourceStartDate;
	@NotEmpty
	private String resourceEndDate;
	@NotEmpty
	@Size(min = 3, message = "Requester name must be minimum of 3 characters")
	private String requestorName;
	@NotEmpty
	@Size(min = 2, message = "Designation must be minimum of 2 characters")
	private String designation;
	@NotEmpty
	@Size(min = 10, message = "Contact must be minimum of 10 characters")
	private String contactNumber;
	/*
	 * @Email(message = "Email address is not valid !!")
	 * 
	 * @NotEmpty(message = "Email is required !!") private String email;
	 */
	@Min(value = 1, message = "Number of opening must be greater than 0")
	private Integer numberOfPositions;
	
	
	// JOIN WITH USERS

	//private int empid;
	@NotEmpty
	@Size(min = 5, message = "Experience Level must be minimum of 5 characters")
	private String experienceLevel;
	@NotEmpty
	private String modeOfWork;
	@NotEmpty
	@Size(min = 15, message = "Job Description must be minimum of 15 characters")
	private String jobDescription;
	@NotEmpty
	private String ctcOfferDetails;
	@NotEmpty
	@Size(min = 3, message = "Work location must be minimum of 3 characters")
	private String workLocation;
	@NotEmpty
	@Size(min = 3, message = "Client Name must be minimum of 3 characters")
	private String client;

	private String division;


	//private List<String> skill;


	private List<String> skill;

	private Boolean isActive;
}
